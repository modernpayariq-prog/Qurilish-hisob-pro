plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "uz.qurilishhisobpro"
    compileSdk = 35

    defaultConfig {
        applicationId = "uz.qurilishhisobpro"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
