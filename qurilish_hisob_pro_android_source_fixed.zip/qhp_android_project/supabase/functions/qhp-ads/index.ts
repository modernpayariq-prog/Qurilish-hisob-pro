import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};
const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { ...corsHeaders, "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" },
});

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  const url = new URL(req.url);
  const path = url.pathname.split("/").filter(Boolean);
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !serviceKey) return json({ error: "Server is not configured" }, 500);

  // The service-role key must remain only in Edge Function secrets, never in Android or HTML.
  const db = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false } });

  if (req.method === "GET" && path.at(-1) === "active") {
    const now = new Date().toISOString();
    const { data, error } = await db.from("qhp_ads")
      .select("id,company,title,description,phone,website,image_url,enabled,starts_at,ends_at")
      .eq("enabled", true).eq("status", "approved")
      .or(`starts_at.is.null,starts_at.lte.${now}`)
      .or(`ends_at.is.null,ends_at.gte.${now}`)
      .order("created_at", { ascending: false }).limit(20);
    if (error) return json({ error: "Could not load ads" }, 500);
    const ads = (data ?? []).map((ad) => ({
      id: ad.id, company: ad.company, title: ad.title, description: ad.description,
      phone: ad.phone, website: ad.website, imageUrl: ad.image_url,
      enabled: ad.enabled, startsAt: ad.starts_at, endsAt: ad.ends_at,
    }));
    return json({ ads });
  }

  // POST /<ad-uuid>/events with { "event": "impression" | "click" }
  if (req.method === "POST" && path.length >= 2 && path.at(-1) === "events") {
    const adId = path.at(-2) ?? "";
    if (!/^[0-9a-f-]{36}$/i.test(adId)) return json({ error: "Invalid ad id" }, 400);
    let body: { event?: string };
    try { body = await req.json(); } catch { return json({ error: "Invalid JSON" }, 400); }
    if (body.event !== "impression" && body.event !== "click") return json({ error: "Invalid event" }, 400);

    // Public event endpoints can be abused. Add server-side rate limiting/WAF before production launch.
    const { data: ad, error: adError } = await db.from("qhp_ads").select("id,enabled,status,starts_at,ends_at").eq("id", adId).maybeSingle();
    if (adError || !ad || !ad.enabled || ad.status !== "approved") return json({ error: "Ad not active" }, 404);
    const now = Date.now();
    if ((ad.starts_at && Date.parse(ad.starts_at) > now) || (ad.ends_at && Date.parse(ad.ends_at) < now)) return json({ error: "Ad not active" }, 404);
    const { error } = await db.from("qhp_ad_events").insert({ ad_id: adId, event_type: body.event });
    if (error) return json({ error: "Could not record event" }, 500);
    return json({ ok: true }, 201);
  }
  return json({ error: "Not found" }, 404);
});
