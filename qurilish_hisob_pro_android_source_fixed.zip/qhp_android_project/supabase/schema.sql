-- Qurilish Hisob Pro: Supabase database schema
-- Run in Supabase SQL Editor as project owner.
create extension if not exists pgcrypto;

create table if not exists public.qhp_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create or replace function public.qhp_is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.qhp_admins a where a.user_id = auth.uid()
  );
$$;
revoke all on function public.qhp_is_admin() from public;
grant execute on function public.qhp_is_admin() to authenticated;

create table if not exists public.qhp_ads (
  id uuid primary key default gen_random_uuid(),
  company text not null check (char_length(company) between 1 and 100),
  title text not null check (char_length(title) between 1 and 100),
  description text not null default '' check (char_length(description) <= 260),
  phone text not null default '' check (char_length(phone) <= 40),
  website text not null default '',
  image_url text not null default '',
  price_uzs bigint not null default 0 check (price_uzs >= 0),
  enabled boolean not null default false,
  status text not null default 'draft' check (status in ('draft','pending','approved','rejected')),
  starts_at timestamptz,
  ends_at timestamptz,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint qhp_ad_dates_valid check (starts_at is null or ends_at is null or ends_at >= starts_at)
);

create index if not exists qhp_ads_active_idx
  on public.qhp_ads (enabled, status, starts_at, ends_at);

create table if not exists public.qhp_ad_events (
  id bigint generated always as identity primary key,
  ad_id uuid not null references public.qhp_ads(id) on delete cascade,
  event_type text not null check (event_type in ('impression','click')),
  created_at timestamptz not null default now()
);
create index if not exists qhp_ad_events_ad_date_idx
  on public.qhp_ad_events (ad_id, created_at desc);

alter table public.qhp_admins enable row level security;
alter table public.qhp_ads enable row level security;
alter table public.qhp_ad_events enable row level security;

-- Admin list is not publicly readable/writable. Admin management is done by project owner in SQL.
drop policy if exists "qhp admins can read admin list" on public.qhp_admins;
create policy "qhp admins can read admin list" on public.qhp_admins
  for select to authenticated using (public.qhp_is_admin());

-- Only registered QHP admins may create/edit/delete ads in the cloud dashboard.
drop policy if exists "qhp admins manage ads" on public.qhp_ads;
create policy "qhp admins manage ads" on public.qhp_ads
  for all to authenticated
  using (public.qhp_is_admin())
  with check (public.qhp_is_admin());

-- Browser/mobile clients cannot insert fake analytics directly; the Edge Function uses service role.
-- No client policies are created for qhp_ad_events.
revoke all on public.qhp_admins from anon, authenticated;
grant select on public.qhp_admins to authenticated;
revoke all on public.qhp_ads from anon, authenticated;
grant select, insert, update, delete on public.qhp_ads to authenticated;
revoke all on public.qhp_ad_events from anon, authenticated;

-- After creating an admin user in Authentication > Users, add their UUID:
-- insert into public.qhp_admins(user_id) values ('PASTE-AUTH-USER-UUID-HERE');
