# Qurilish Hisob Pro — Android va reklama tizimi

Bu loyiha mavjud HTML prototipni Android WebView ichida ochadi. Qurilish hisob-kitoblari hozircha ilovaning mahalliy HTML interfeysida ishlaydi. Reklama tizimi uchun Supabase serveri va ma’lumotlar bazasi sxemasi qo‘shildi.

## Loyiha tarkibi

- `app/src/main/assets/index.html` — Qurilish Hisob Pro interfeysi va internetdan faol reklama olish uchun klient kodi.
- `app/src/main/java/uz/qurilishhisobpro/MainActivity.kt` — Android WebView oynasi.
- `ads-admin/index.html` — brauzer xotirasida ishlaydigan eski, lokal prototip.
- `ads-admin/cloud-admin.html` — Supabase serveriga ulanadigan administrator paneli. Ishlatishdan oldin URL va anon key bilan sozlanadi.
- `supabase/schema.sql` — reklama, administrator va statistika jadvallari hamda RLS siyosatlari.
- `supabase/functions/qhp-ads/index.ts` — faol reklamalarni uzatish va ko‘rsatish/bosish hodisalarini saqlash uchun Edge Function.
- `supabase/config.toml` — reklama endpointi ommaviy GET/POST so‘rovlarini qabul qilishi uchun sozlama. Endpointda maxfiy service-role kaliti klientga berilmaydi.

## A. Supabase serverini sozlash

1. `supabase.com` saytida yangi loyiha yarating. Ma’lumotlar bazasi parolini xavfsiz joyda saqlang.
2. Supabase loyihasida **SQL Editor** ni ochib `supabase/schema.sql` faylining barcha SQL kodini ishga tushiring.
3. **Project Settings → API** bo‘limidan Project URL va `anon/public` kalitini oling. `service_role` kalitini hech qachon brauzer HTML fayliga yoki Android ilovasiga joylamang.
4. **Authentication → Users** orqali administrator foydalanuvchisini yarating. Ommaviy ro‘yxatdan o‘tishni yoqmang; faqat o‘zingiz yaratgan administratorlardan foydalaning.
5. Yaratilgan administrator foydalanuvchisining UUID raqamini oling va SQL Editor’da quyidagini ishga tushiring:

   ```sql
   insert into public.qhp_admins(user_id)
   values ('ADMIN-USER-UUID-HERE');
   ```

   `ADMIN-USER-UUID-HERE` o‘rniga haqiqiy Auth user UUID ni yozing.

6. Supabase CLI o‘rnating, loyiha papkasida `supabase login` va `supabase link --project-ref YOUR_PROJECT_REF` buyruqlarini bajaring.
7. `supabase/config.toml` faylini loyiha konfiguratsiyasi sifatida ishlating va funksiyani deploy qiling:

   ```bash
   supabase functions deploy qhp-ads --no-verify-jwt
   ```

   Supabase Edge Function muhitida `SUPABASE_URL` va `SUPABASE_SERVICE_ROLE_KEY` mavjudligini tekshiring. Agar muhitda avtomatik berilmagan bo‘lsa, Supabase secrets orqali sozlang. Service-role kaliti faqat serverda qolishi shart.

8. Faol reklama API manzili quyidagicha bo‘ladi:

   `https://YOUR-PROJECT.supabase.co/functions/v1/qhp-ads/active`

## B. Administrator panelini sozlash

1. `ads-admin/cloud-admin.html` faylini matn muharririda oching.
2. Fayl oxiridagi `SUPABASE_URL` va `SUPABASE_ANON_KEY` qiymatlarini o‘zingizning loyiha ma’lumotlaringizga almashtiring.
3. Faylni HTTPS bilan xizmat ko‘rsatuvchi statik hostingga joylashtiring (masalan, Vercel, Netlify yoki o‘z domeningiz). Lokal fayl sifatida ochilganda brauzer siyosatlari sababli ayrim autentifikatsiya funksiyalari ishlamasligi mumkin.
4. Administrator email/paroli bilan kiring. RLS siyosati sababli `qhp_admins` jadvaliga qo‘shilmagan foydalanuvchi reklamalarni boshqara olmaydi.
5. Reklamani ko‘rsatish uchun `status = approved` va `enabled = true` bo‘lishi kerak. Boshlanish/tugash vaqti ham tekshiriladi.

## C. Android HTML interfeysini serverga ulash

`app/src/main/assets/index.html` ichidagi `AD_API_URL` quyidagi qiymatga o‘rnatilgan:

```js
const AD_API_URL = "https://YOUR-PROJECT.supabase.co/functions/v1/qhp-ads/active";
```

`YOUR-PROJECT` o‘rniga Supabase loyihangiz subdomenini kiriting. So‘ng Android Studio’da loyihani ochib, Gradle sync qiling va APKni yig‘ing. Server mavjud bo‘lmasa yoki reklama topilmasa, reklama banneri ko‘rsatilmaydi.

## D. API shakli

GET `/active` quyidagi shaklda javob beradi:

```json
{
  "ads": [
    {
      "id": "uuid",
      "company": "Samarqand Qurilish Savdo",
      "title": "Sement va armatura",
      "description": "Narxlar bo‘yicha bog‘laning",
      "phone": "+998901234567",
      "website": "https://example.uz",
      "imageUrl": "https://example.uz/banner.jpg",
      "enabled": true,
      "startsAt": null,
      "endsAt": null
    }
  ]
}
```

Ko‘rsatish/bosish statistikasi POST `/<ad-uuid>/events` manziliga `{"event":"impression"}` yoki `{"event":"click"}` yuborish orqali yoziladi.

## E. Xavfsizlik va ishlab chiqarishga chiqarishdan oldin

- Service-role kalitini hech qachon Android, HTML, JavaScript yoki Git repozitoriyasiga qo‘ymang.
- `qhp_ad_events` jadvaliga klientlardan to‘g‘ridan-to‘g‘ri yozish RLS bilan yopilgan; yozuvlar Edge Function orqali amalga oshadi.
- Ommaviy event endpoint uchun ishlab chiqarishga chiqarishdan oldin haqiqiy rate limit/WAF, soxta bosishlarga qarshi himoya va maxfiylik siyosati qo‘shing. Hozirgi kod to‘liq anti-fraud tizimi emas.
- Reklama rasmlari va tashqi havolalar faqat HTTPS bo‘lishi kerak. Firma reklamalari joylashtirilishidan oldin tekshirilsin.
- Bu bosqichda reklama serveri avtomatik deploy qilinmagan: buning uchun foydalanuvchining Supabase loyihasi va tegishli kirish sozlamalari zarur.
- Reklama faqat Qurilish Hisob Pro ichida ko‘rsatiladi. Boshqa ilovalar ustida kutilmagan oynalar chiqarish tavsiya etilmaydi.
